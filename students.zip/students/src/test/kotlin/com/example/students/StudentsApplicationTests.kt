package com.example.students

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class StudentsApplicationTests {

	@Test
	fun contextLoads() {
	}

}
